#ifndef VAR_H
#define VAR_H

#include "savestate.h"

typedef struct INTELHEX {
	int DataSize;
	int Address;
	int Type;
	BYTE Data[256];
	int CheckSum;
} INTELHEX_t;

#pragma pack(1)

typedef struct TIFLASH {
	unsigned char sig[8];
	unsigned char rev[2];
	unsigned char flag;
	unsigned char object;
	unsigned char date[4];
	unsigned char namelength;
	unsigned char name[8];
	unsigned char filler[23];
	unsigned char device;
	unsigned char type;
	unsigned char filler2[24];
	unsigned int hexsize;
//	int rpage[256];
	int pagesize[256];
	unsigned char *data[256];
//	unsigned short chksum;

	unsigned int pages;		//total number of pages.

} TIFLASH_t;



typedef struct ROM {
	int size;
	char version[32];
	unsigned char *data;
} ROM_t;

typedef struct TIBACKUP {
	unsigned short headersize;		// size of the header up to name, sometimes ignored
	unsigned short length1;			// data size
	unsigned char vartype;			// what type of varible
	unsigned short length2;			// data size
	unsigned short length3;			// data size
	unsigned short address;			// duplicate of data size
	
	unsigned short length1a;		// Repeats of the data length.
	unsigned char *data1;			// pointer to data

	unsigned short length2a;		// data size
	unsigned char *data2;			// pointer to data

	unsigned short length3a;		// data size
	unsigned char *data3;			// pointer to data


} TIBACKUP_t;

typedef struct TIVAR {
	unsigned short headersize;		// size of the header up to name, sometimes ignored
	unsigned short length;			// data size
	unsigned char vartype;			// what type of variable
	unsigned char name_length;		// 85/86 only name length is variable
	unsigned char name[8];			// null padded name
	unsigned char version;			// 0 83+only
	unsigned char flag;				// bit 7 is if flash 83+only
	unsigned short length2;			// duplicate of data size
	unsigned char *data;			// pointer to data
} TIVAR_t;

typedef enum {
	ROM_TYPE = 1,			// Rom
	FLASH_TYPE = 2,			// Flash application or OS
	VAR_TYPE = 3,			// most varibles can be supported under an umbrella type
	SAV_TYPE = 4,			// Wabbit specific saves.
	BACKUP_TYPE = 5,		// Wabbit specific saves.
	LABEL_TYPE = 6,			// Lab file
	BREAKPOINT_TYPE = 7,	// breakpoint file
	GROUP_TYPE = 8,			// groups are stored weirdly so they get a weird type
	ZIP_TYPE = 9,			// zip/tig file
} TifileVarType_t;

typedef struct TIFILE {
	unsigned char sig[8];
	unsigned char subsig[3];
	unsigned char comment[42];
	unsigned char length;
	TIVAR_t *var;
	TIVAR_t *vars[256];
	unsigned char chksum;
	CalcModel model;
	TifileVarType_t type;
	ROM_t *rom;
	TIFLASH_t *flash;
	SAVESTATE_t *save;
	TIBACKUP_t *backup;
} TIFILE_t;


#pragma pack()

#define TI_FLASH_HEADER_SIZE 8+2+1+1+4+1+8+23+1+1+24+4
#define TI_FILE_HEADER_SIZE 8+3+42/*+2*/
#define TI_VAR_HEADER_SIZE 2+2+1+8

#define FLASH_TYPE_OS 0x23
#define FLASH_TYPE_APP 0x24

CalcModel FindRomVersion(char*, unsigned char*, u_int);
int ReadIntelHex(FILE *ifile, INTELHEX_t *ihex);
TIFILE_t* importvar(LPCTSTR FilePath, BOOL only_check_header);
TIFILE_t* FreeTiFile(TIFILE_t *);

#endif
